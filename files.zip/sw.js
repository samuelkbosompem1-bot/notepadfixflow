// FixFlow service worker.
// IMPORTANT: the HTML document itself is network-first — we always try to
// fetch the latest version and only fall back to cache if offline. A
// cache-first strategy on index.html would silently freeze the app at
// whatever version was live when the service worker first installed,
// ignoring every future deploy. Static assets (icons, manifest) that rarely
// change are still cache-first for speed and offline support.
const CACHE_NAME = 'fixflow-shell-v2';
const STATIC_FILES = ['/manifest.json', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(STATIC_FILES))
      .catch((e) => console.error('FixFlow SW install error:', e))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;

  const isHtmlDocument = req.mode === 'navigate' || url.pathname === '/' || url.pathname === '/index.html';
  if (isHtmlDocument) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req))
    );
    return;
  }

  // Static assets: cache-first, since these rarely change.
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req))
  );
});
